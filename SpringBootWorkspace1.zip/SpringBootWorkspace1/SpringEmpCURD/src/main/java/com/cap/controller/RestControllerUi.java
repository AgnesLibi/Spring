package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.Employee;
import com.cap.service.EmployeeService;



@RestController
@RequestMapping("/Bank")
public class RestControllerUi {
	@Autowired
	EmployeeService service;
	
	@PostMapping("/createaccount")
	public List<Employee> createAccount(@RequestBody Employee emp){//@PathVariable
		return service.createEmployee(emp);
	}
	
//	@GetMapping("/")
	@GetMapping("/findEmployee/{id}")
    public Employee accountsDetails(@PathVariable int id) {
        return service.accountsDetails(id);
    }
 
	@PutMapping("/update/{eid}/{amt}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable int eid,@PathVariable int amt)
   
    {
        Employee i= service.updateEmployee(eid,amt);
        return new ResponseEntity<Employee>(i,HttpStatus.OK);
       
    }

}
