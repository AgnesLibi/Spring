package com.cap.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.EmployeeDao;
import com.cap.entities.Employee;
@Service
public class EmployeeServiceImp1 implements EmployeeService {
	@Autowired
	EmployeeDao empdao;

	@Override
	public List<Employee> createEmployee(Employee emp) {
		empdao.save(emp);
		return empdao.findAll();
	}
	

	@Override
    public Employee accountsDetails(Integer id) {
		empdao.findById(id);
        return empdao.findById(id).get();
    }
   
	public Employee updateEmployee(int eid, int amt) {
        Optional<Employee> emp=empdao.findById(eid);
        Employee tempemp;
        if(emp.isPresent())
        {
            tempemp=emp.get();
            tempemp.setSal(emp.get().getSal()+amt);
            empdao.save(tempemp);
        }
        return empdao.findById(eid).get();
    }
}
