package com.capgemini.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.Stock;

//It indicates that the class is used for storage,search,update,etc
@Repository
public interface StockDao extends JpaRepository<Stock, Integer> {

}
