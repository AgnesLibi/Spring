package com.first;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test 
{
	public static void main(String[] args) 
	{
		Resource resource=new ClassPathResource("applicationContext.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		Employee ob=(Employee) factory.getBean("emp");
		Employee ob1= (Employee) factory.getBean("emp1");
		//or
		//Employee ob2=factory.getBean(Employee.class,"emp");
		ob.display();
		ob1.display();
		//ob2.display();
		
	}
}
