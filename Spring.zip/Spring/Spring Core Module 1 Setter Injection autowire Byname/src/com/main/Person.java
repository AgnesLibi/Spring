package com.main;

public class Person 
{
	private int pid;
	private String pFname;
	private String pLname;
	private Address add;
	
	
	
	public Address getAdd() {
		return add;
	}
	public void setAdd(Address add) {
		this.add = add;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpFname() {
		return pFname;
	}
	public void setpFname(String pFname) {
		this.pFname = pFname;
	}
	public String getpLname() {
		return pLname;
	}
	public void setpLname(String pLname) {
		this.pLname = pLname;
	}
	
	public void display()
	{
		System.out.println(pid+"  "+pFname+"  "+pLname+"  "+add);
	}
}
