package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test 
{
	public static void main(String[] args) 
	{
		ApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Employee e=(Employee) context.getBean("emp");
		//or
		//Employee e=(Employee) context.getBean(Employee.class);
		//or 
		//Employee e=(Employee) context.getBean(employee);.....//this is reference
		e.setEid(1);
		e.setEname("Agnes");
		e.display();
		
	}
}
