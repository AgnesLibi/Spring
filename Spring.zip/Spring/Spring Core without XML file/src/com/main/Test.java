package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test 
{
	public static void main(String[] args) 
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		Object obj=context.getBean("emp",Employee.class);
		Employee e=(Employee) obj;
		e.setEid(1);
		e.setEname("Agnes");
		e.display();
		
	}
}
