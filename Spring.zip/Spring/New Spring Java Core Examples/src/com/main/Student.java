package com.main;

public class Student {

	private int StuId;
	private String StuName;
	private int StuMarks;
	
	
	public int getStuId() {
		return StuId;
	}
	public void setStuId(int stuId) {
		StuId = stuId;
	}
	public String getStuName() {
		return StuName;
	}
	public void setStuName(String stuName) {
		StuName = stuName;
	}
	public int getStuMarks() {
		return StuMarks;
	}
	public void setStuMarks(int stuMarks) {
		StuMarks = stuMarks;
	}
	
	public void display()
	{
		System.out.println("Id"+"   "+"Name"+"   "+"Marks");
		System.out.println("******************************");
		System.out.println(StuId+"  "+StuName+"  "+StuMarks);
		System.out.println("\n\n");
	}
	
	public Student(int stuId, String stuName, int stuMarks) {
		super();
		StuId = stuId;
		StuName = stuName;
		StuMarks = stuMarks;
	}
	public Student() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [StuId=" + StuId + ", StuName=" + StuName + ", StuMarks=" + StuMarks + "]";
	}
	
	
}
