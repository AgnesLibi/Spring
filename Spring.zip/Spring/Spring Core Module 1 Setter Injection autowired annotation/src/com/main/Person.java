package com.main;

import org.springframework.beans.factory.annotation.Autowired;

public class Person {
	private int pid;
	private String pFname;
	private String pLname;
	
	private Address add;

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getpFname() {
		return pFname;
	}

	public void setpFname(String pFname) {
		this.pFname = pFname;
	}

	public String getpLname() {
		return pLname;
	}

	public void setpLname(String pLname) {
		this.pLname = pLname;
	}

	public Address getAdd() {
		return add;
	}
	@Autowired
	public void setAdd(Address add) {
		this.add = add;
	}

	public void display() {
		System.out.println(pid + "  " + pFname + "  " + pLname + "  " + add);
	}
}
