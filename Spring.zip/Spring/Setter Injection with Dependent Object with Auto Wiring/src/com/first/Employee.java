package com.first;

public class Employee {

	private int eid;
	private String ename;
	private Address add;//has-a
	private Taddress tadd;

	public Taddress getTadd() {
		return tadd;
	}

	public void setTadd(Taddress tadd) {
		this.tadd = tadd;
	}

	public Address getAdd() {
		return add;
	}

	public void setAdd(Address add) {
		this.add = add;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", add=" + add + ", tadd=" + tadd + "]";
	}

	public void display() {
		System.out.println("Id"+"   "+"name"+"   "+"Address"+"  "+"Taddress");
		System.out.println("*********************");
		System.out.println(eid+ "  "+ename+"   "+add+"  "+tadd);
		
	}

}
