package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test 
{
	public static void main(String[] args) 
	{
		Resource resource=new ClassPathResource("applicationContext.xml"); 
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		Person p=(Person) context.getBean("per");
		p.display();
	}
}
