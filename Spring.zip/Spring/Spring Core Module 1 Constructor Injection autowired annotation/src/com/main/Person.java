package com.main;

import org.springframework.beans.factory.annotation.Autowired;

public class Person 
{
	private int pid;
	private String pFname;
	private String pLname;
	
	private Address add;
	
	@Autowired
	public Person(int pid, String pFname, String pLname, Address add) {
		super();
		this.pid = pid;
		this.pFname = pFname;
		this.pLname = pLname;
		this.add = add;
	}
	public void display()
	{
		System.out.println(pid+"  "+pFname+"  "+pLname+"  "+add);
	}
}
