package com.first;

import java.util.Iterator;
import java.util.Set;

public class Employee {

	private int eid;
	private String ename;
	private Set<String> eadd;
	

	public Set<String> getEadd() {
		return eadd;
	}

	public void setEadd(Set<String> eadd) {
		this.eadd = eadd;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", eadd=" + eadd + "]";
	}

	public void display() {
		System.out.println(ename+":");
		 Iterator itr=eadd.iterator();
	        while (itr.hasNext()) {
	            System.out.println(itr.next()+" ");
	        }}

}
