package com.abc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController 
{
	@RequestMapping("/login")
	//We can use @RequestParam to get user data to controller
	public ModelAndView helloworld(HttpServletRequest request,HttpServletResponse response)
	{
		String name=request.getParameter("uname");
		String pass=request.getParameter("pass");
		if(pass.equals("admin"))
		{
			String message="Hello"+"  "+name;
			ModelAndView mv=new ModelAndView();
			mv.addObject("print",message);
			mv.setViewName("HelloPage");
			return mv;
		}
		else
		{
		return new ModelAndView("errorPage","message","Sorry, Username and password does not match");
		}
		
	}
}
