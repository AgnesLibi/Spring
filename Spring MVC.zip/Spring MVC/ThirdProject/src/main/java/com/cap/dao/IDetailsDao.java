package com.cap.dao;

import com.cap.entities.User;

public interface IDetailsDao {

    User findUserById(int id);

    User createUser(User user);

    User createUser(String username);
}