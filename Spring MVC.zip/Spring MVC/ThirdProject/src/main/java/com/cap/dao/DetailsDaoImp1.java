package com.cap.dao;

import com.cap.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.HashMap;
import java.util.Map;

/**
 * marking with @Repository is similar to @Component but used for Dao implementation classes,
 * spring will keep instance of DetailsDaoImpl and the object will be kept in bean factory
 *
 */
@Repository//@Service,@Component,@Enitty
public class DetailsDaoImp1 implements IDetailsDao {

    @PersistenceContext
    private EntityManager em;

    public DetailsDaoImp1(){
    }

   
    public User findUserById(int id) {
      User u= em.find(User.class,id);
      return u;
    }

   
    public User createUser(User user){
        user=em.merge(user);
        return user;
    }

 
    public User createUser(String name) {
        User user=new User();
        user.setName(name);
        user=em.merge(user);
        return user;
    }
}